#ifndef ORDENADOR_H
#define  ORDENADOR_H

#include "estrt_const_bibliot.h"

typedef char* Type;

#endif
